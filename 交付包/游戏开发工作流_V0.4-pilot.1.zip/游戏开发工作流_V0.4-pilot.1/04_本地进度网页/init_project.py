"""Initialize a new customer's records without overwriting an existing project."""
from pathlib import Path
import shutil
import workflow
import improvement


def main():
    initial = workflow.seed()  # Validate configuration before copying anything.
    target = workflow.ROOT / '项目记录'
    if target.exists() and any(target.iterdir()):
        raise SystemExit('项目记录目录已有内容。为保护成果，初始化已停止。')
    target.mkdir(exist_ok=True)
    for source in (workflow.ROOT / '05_项目模板').glob('*.md'):
        if source.name not in ('使用说明.md', 'CODEX_HANDOFF.md'):
            shutil.copyfile(source, target / source.name)
            if not (target / source.name).is_file():
                raise SystemExit('模板复制失败：' + source.name)
    card = target / '当前操作' / 'T00_准备协作.md'
    card.parent.mkdir(exist_ok=True)
    shutil.copyfile(workflow.ROOT / '05_项目模板/首次操作/T00_准备协作.md', card)
    if not card.is_file():
        raise SystemExit('首次操作卡复制失败。')
    initial['tasks'][0]['instructions'] = card.relative_to(workflow.ROOT).as_posix()
    workflow.validate(initial, workflow.ROOT)
    workflow.atomic(target / 'state.json', initial)
    workflow.atomic(target / improvement.NAME, improvement.seed())
    print('项目记录已初始化；所有任务均未验收。')


if __name__ == '__main__':
    main()
